export class UkmModel {
    constructor(
        public id: string,
        public title: string,
        public desc: string
    ) { }
}