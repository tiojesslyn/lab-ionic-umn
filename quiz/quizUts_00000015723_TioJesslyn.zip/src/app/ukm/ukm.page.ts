import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ukm',
  templateUrl: './ukm.page.html',
  styleUrls: ['./ukm.page.scss'],
})
export class UkmPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
